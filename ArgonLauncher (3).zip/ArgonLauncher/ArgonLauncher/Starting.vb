﻿Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text

Public Class Starting

    Dim res

    <DllImport("kernel32")>
    Private Shared Function GetPrivateProfileString(ByVal section As String, ByVal key As String, ByVal def As String, ByVal retVal As StringBuilder, ByVal size As Integer, ByVal filePath As String) As Integer
    End Function

    Public Function GetIniValue(section As String, key As String, filename As String, Optional defaultValue As String = "") As String
        Dim sb As New StringBuilder(500)
        If GetPrivateProfileString(section, key, defaultValue, sb, sb.Capacity, filename) > 0 Then
            Return sb.ToString
        Else
            Return defaultValue
        End If
    End Function

    Public Function GETRequest(ByVal URL)
        Dim request As String = URL
        Dim webClient As New System.Net.WebClient
        Dim result As String = webClient.DownloadString(request)
        Return result
    End Function

    Private Sub Starting_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AppTimer.Start()
    End Sub

    Private Sub AppTimer_Tick(sender As Object, e As EventArgs) Handles AppTimer.Tick
        AppTimer.Stop()
        res = GETRequest(Form1.ServerURL)
        If (File.Exists(Application.StartupPath + "/UPDATE.ini")) Then
            File.Delete(Application.StartupPath + "/UPDATE.ini")
        End If
        ' summon the file returning from the GET request
        Dim path As String = Application.StartupPath + "/UPDATE.ini"
        Dim fs As FileStream = File.Create(path)
        Dim info As Byte() = New UTF8Encoding(True).GetBytes(res)
        fs.Write(info, 0, info.Length)
        fs.Close()
        Form1.Show()
        Form1.NEWAPPVERSION = GetIniValue("APP", "V", Application.StartupPath + "/UPDATE.ini")
        Form1.beginupdate()
        Me.Hide()
    End Sub
End Class