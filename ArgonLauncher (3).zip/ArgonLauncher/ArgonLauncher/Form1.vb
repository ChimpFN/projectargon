﻿Imports System.Runtime.InteropServices
Imports System.Text
Imports System.IO
Imports System.Net
Imports System.Reflection.Emit
Imports System.Web.Caching
Imports System.Web.UI.WebControls
Imports Guna.UI2.WinForms.Suite
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form1
    Public Sub ResponsiveSleep(ByRef iMilliSeconds As Integer)
        Dim i As Integer, iHalfSeconds As Integer = iMilliSeconds / 500
        For i = 1 To iHalfSeconds
            Threading.Thread.Sleep(500) : Application.DoEvents()
        Next i
    End Sub
    Public ServerURL = "" ' The link to the .INI file (server hosted)
    Dim APPVERSION = ""
    Public NEWAPPVERSION = ""
    Dim Row As Boolean = True
    Dim StartDL As Boolean = False
    Public WithEvents downloader As WebClient
    Public GamePath = Application.StartupPath + "/FortniteGame/Binaries/Win64/Fortnite-Shipping.exe"

    <DllImport("kernel32")>
    Private Shared Function GetPrivateProfileString(ByVal section As String, ByVal key As String, ByVal def As String, ByVal retVal As StringBuilder, ByVal size As Integer, ByVal filePath As String) As Integer
    End Function

    Public Function GetIniValue(section As String, key As String, filename As String, Optional defaultValue As String = "") As String
        Dim sb As New StringBuilder(500)
        If GetPrivateProfileString(section, key, defaultValue, sb, sb.Capacity, filename) > 0 Then
            Return sb.ToString
        Else
            Return defaultValue
        End If
    End Function

    Dim progress

    Public Sub DownloadStart(ByVal DownloadLink)
        LogLabel.Text = "Downloading... "
        Log(">>>> START DOWNLOAD")
        Log("[ACTION] Requesting file to source provider.")
        downloader = New WebClient
        AddHandler downloader.DownloadProgressChanged, AddressOf downloader_DownloadProgressChanged
        AddHandler downloader.DownloadFileCompleted, AddressOf DownloadComplete
        Log("[TRACE] ASYNC DOWNLOAD START ///")
        downloader.DownloadFileAsync(New Uri(DownloadLink), Application.StartupPath + "\latest.zip")
    End Sub

    Private Sub downloader_DownloadProgressChanged(sender As Object, e As DownloadProgressChangedEventArgs) Handles downloader.DownloadProgressChanged
        Guna2ProgressBar1.Value = e.ProgressPercentage
        progress = e
        Log("{DownloadScript} Bytes recieved: " + e.BytesReceived.ToString + "/" + e.TotalBytesToReceive.ToString)
        LogLabel.Text = "Downloading... " + e.ProgressPercentage.ToString + "%"
    End Sub

    Public Sub Log(ByVal str)
        RichTextBox1.AppendText(str + vbNewLine)
    End Sub

    Sub CreateAPP(res)
        If File.Exists(Application.StartupPath + "/APP.INI") Then
            File.Delete(Application.StartupPath + "/APP.INI")
        End If
        Dim path As String = Application.StartupPath + "/APP.INI"
        Dim fs As FileStream = File.Create(path)
        Dim info As Byte() = New UTF8Encoding(True).GetBytes(res)
        fs.Write(info, 0, info.Length)
        fs.Close()
    End Sub

    Sub beginupdate()
        APPVERSION = GetIniValue("APP", "V", Application.StartupPath + "/appversion.ogz")
        If Not APPVERSION = NEWAPPVERSION Then
            UpdateBtn.Show()
        End If
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Application.Exit()
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged
        ' Sets the starting point of the selection         
        RichTextBox1.SelectionStart = Len(RichTextBox1.Text) + 1
        ' Scrolls to the caret
        RichTextBox1.ScrollToCaret()
        ' Select the range 
        RichTextBox1.Select()
    End Sub

    Private Sub UpdateBtn_Click(sender As Object, e As EventArgs) Handles UpdateBtn.Click
        If StartDL = False Then
            StartDL = True
            Guna2Transition1.ShowSync(Guna2ShadowPanel1)
            startupdate()
        End If
    End Sub

    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click
        If Row Then
            Guna2Transition1.ShowSync(Guna2Button3)
            Row = False
        Else
            Guna2Transition1.HideSync(Guna2Button3)
            Row = True
        End If
    End Sub

    Public Sub startupdate()
        ' Log("[LOG] ")
        Log("[LOG] Locking game status")
        DownloadStart(GetIniValue("APP", "LNK", Application.StartupPath + "/UPDATE.ini"))
    End Sub

    Public Sub DownloadComplete()
        Log("[TRACE] Download Completed !")
        LogLabel.Text = "Extracting..."
        Guna2ProgressBar1.Style = ProgressBarStyle.Marquee
        Log("[ACTION] ResetProgressBar | ResetTaskBar | Unpackage")
        ResponsiveSleep(1000)
        Guna2ProgressBar1.Value = 0
        Try
            Log(">>>> UNPACKAGE START")
            If Directory.Exists(Application.StartupPath + "/FortniteGame") Then
                Log("[TRACE] Delete FortniteGame...")
                My.Computer.FileSystem.DeleteDirectory(Application.StartupPath + "/FortniteGame", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
                Log("[TRACE] Done.")
            End If
            If Directory.Exists(Application.StartupPath + "/Engine") Then
                Log("[TRACE] Delete Engine...")
                My.Computer.FileSystem.DeleteDirectory(Application.StartupPath + "/Engine", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
                Log("[TRACE] Done.")
            End If
            Log("[TRACE] Unpackage latest.zip ///")
            Compression.ZipFile.ExtractToDirectory(Application.StartupPath + "\latest.zip", Application.StartupPath + "\")
            Log("[TRACE] Unpackage done ///")
            Log(">>>> UNPACKAGE END")
            Log("")
            ResponsiveSleep(1000)
            Log("[TRACE] Restart needed | Notifying user")
            ShowInfoMessage("Update Completed", "We will now restart the launcher.")
            If File.Exists(Application.StartupPath + "\appversion.ogz") Then
                File.Delete(Application.StartupPath + "\appversion.ogz")
                Dim path As String = Application.StartupPath + "\appversion.ogz"
                Dim fs As FileStream = File.Create(path)
                Dim info As Byte() = New UTF8Encoding(True).GetBytes("[APP]" + vbNewLine + "V=" + NEWAPPVERSION)
                fs.Write(info, 0, info.Length)
                fs.Close()
            Else
                Dim path As String = Application.StartupPath + "\appversion.ogz"
                Dim fs As FileStream = File.Create(path)
                Dim info As Byte() = New UTF8Encoding(True).GetBytes("[APP]" + vbNewLine + "V=" + NEWAPPVERSION)
                fs.Write(info, 0, info.Length)
                fs.Close()
            End If
            File.Delete(Application.StartupPath + "/latest.zip")
            Application.Restart()
        Catch ex As Exception
            ShowErrMessage("Oops...", ex.ToString)
            ResponsiveSleep(2500)
            Me.Close()
        End Try
    End Sub

    Public Sub ShowErrMessage(ByVal Title, ByVal Text)
        DialogM.Caption = Title
        DialogM.Text = Text
        DialogM.Style = Guna.UI2.WinForms.MessageDialogStyle.Dark
        DialogM.Icon = Guna.UI2.WinForms.MessageDialogIcon.Error
        DialogM.Show()
    End Sub

    Public Sub ShowInfoMessage(ByVal Title, ByVal Text)
        DialogM.Caption = Title
        DialogM.Text = Text
        DialogM.Style = Guna.UI2.WinForms.MessageDialogStyle.Dark
        DialogM.Icon = Guna.UI2.WinForms.MessageDialogIcon.Information
        DialogM.Show()
    End Sub

    Private Sub PlayBtn_Click(sender As Object, e As EventArgs) Handles PlayBtn.Click
        Process.Start(GamePath)
    End Sub
End Class
